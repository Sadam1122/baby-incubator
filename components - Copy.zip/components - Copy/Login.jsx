import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, Link } from "react-router-dom";
import { FaLock, FaUserAlt } from 'react-icons/fa'; 
import { LoginUser, reset } from "../features/authSlice";



const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user, isError, isSuccess, isLoading, message } = useSelector(
    (state) => state.auth
  );

  useEffect(() => {
    if (user || isSuccess) {
      navigate("/dashboard");
    }
    dispatch(reset());
  }, [user, isSuccess, dispatch, navigate]);

  const handleSubmit = (event) => {
    event.preventDefault();
  };

  const handleInput = (event) => {
    const { name, value } = event.target;
    if (name === 'email') {
      setEmail(value);
    } else if (name === 'password') {
      setPassword(value);
    }
  };


  return (
    <section style={{ display: "flex", height: "100vh" }}>
      <div
        style={{
          backgroundColor: "darkred",
          flex: 1,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          color: "white",
        }}
      >
        <div style={{ textAlign: 'center' }}>   
          <img src={require('./ATUR (2) 1.png')} alt="ATUR Logo" style={{ maxWidth: '30vw', maxHeight: '30vh' }} />
          <h1 style={{ fontSize: '3vw', fontWeight: 'bold' }}>SELAMAT DATANG DI ATUR</h1>
          <p style={{ fontSize: '2vw' }}>Artificial Intelligence Task Automation and Regulation</p>
          <p style={{ fontSize: '1.5vw' }}>Mendata hasil inkubator serta uji kelayakan sesuai standarisasi</p>
          <img src={require('./koran.png')} alt="koran" style={{ maxWidth: '40vw', maxHeight: '40vh' }} />
        </div>
      </div>

      <div
        style={{
          flex: 1,
          backgroundColor: "white",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div className="right-pane">
          <div className='bg-white p-3 rounded w-100' style={{ maxWidth: '400px', margin: 'auto' }}>
            <form onSubmit={handleSubmit}>
              {isError && <p className="has-text-centered" style={{ color: 'red', marginBottom: '1rem' }}>{message}</p>}
              <h2 style={{ marginBottom: '1rem', fontSize: '2rem', textAlign: 'center', fontWeight: 'bold' }}>Masuk</h2>
              <div className='mb-3'>
                <label htmlFor='email' style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>Email</label>
                <div className="input-group">
                  <span className="input-group-text"><FaUserAlt /></span>
                  <input
                    type='email'
                    placeholder='Masukan Email'
                    name='email'
                    value={email}
                    onChange={handleInput}
                    className='form-control rounded-0'
                    style={{ fontSize: '1rem' }}
                  />
                </div>
              </div>
              <div className='mb-3'>
                <label htmlFor='password' style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>Password</label>
                <div className="input-group">
                  <span className="input-group-text"><FaLock /></span>
                  <input
                    type='password'
                    placeholder='Masukan kata Sandi'
                    name='password'
                    value={password}
                    onChange={handleInput}
                    className='form-control rounded-0'
                    style={{ fontSize: '1rem' }}
                  />
                </div>
              </div>
              <button
                type='submit'
                className='btn btn-success w-100 rounded-0 custom-button'
                style={{
                  backgroundColor: '#4CAF50', 
                  color: 'white', 
                  border: 'none',
                  padding: '10px 20px', 
                  fontSize: '1rem', 
                  borderRadius: '20px', 
                  cursor: 'pointer' 
                }}
              >
                <strong>Masuk</strong>
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;
